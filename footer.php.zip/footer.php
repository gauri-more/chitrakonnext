
   <footer>

      <!-- footer area start -->
      <div class="tp-footer-area tp-footer-space p-relative z-index-3 black-bg">
         <div class="tp-footer-shape-1 d-none d-lg-block">
            <img src="assets/img/footer/shape-1-1.png" alt="">
         </div>
         <div class="tp-footer-shape-2 d-none d-lg-block">
            <img src="assets/img/footer/shape-1-2.png" alt="">
         </div>
         <div class="container">
            <div class="row">
               <div class="col-xl-5 col-lg-5 col-md-6 col-sm-6 mb-50 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                  <div class="tp-footer-widget footer-cols-1">
                     <div class="tp-footer-logo">
                        <a href="index.php"><img src="assets/Images/ckt-white-logo-new.png" alt="" style="    height: 100px;"></a>
                     </div>
                     <div class="tp-footer-text">
                      <p>
CKT is a trusted manufacturer of premium wire harnesses, providing innovative connectivity solutions for automotive,
industrial, and electrical applications. We are committed to delivering quality products with precision and on-time execution.
</p>
                     </div>
                     <div class="tp-footer-contact">
                        <a href="mailto:Chaitrakt.marketing@gmail.com"><i
                              class="flaticon-mail-1"></i>Chaitrakt.marketing@gmail.com</a>
                        <a href="#"><i class="flaticon-location-1"></i>Ground Floor, Gate No: 2075, Kude Farm, Old Pune-Mumbai Highway Opps. Vakratunda Tyres, Vadgaon, Maval, Pune - 412106. </a>
                     </div>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-50 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".5s">
                  <div class="tp-footer-widget footer-cols-2">
                     <h4 class="tp-footer-title">Usefull Links</h4>
                     <div class="tp-footer-list">
                        <ul>
                           <li><a href="about-us.php"><i class="fa-sharp fa-solid fa-plus"></i>About CKT</a></li>
                           <li><a href="service.php"><i class="fa-sharp fa-solid fa-plus"></i>Our Services</a></li>
                           <li><a href="gallery.php"><i class="fa-sharp fa-solid fa-plus"></i>Gallery</a></li>
                           <li><a href="certification.php"><i class="fa-sharp fa-solid fa-plus"></i>Our Certification</a></li>
                           <li><a href="contact.php"><i class="fa-sharp fa-solid fa-plus"></i>Contact</a></li>
                        
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-50 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".7s">
                  <div class="tp-footer-widget footer-cols-3">
                     <h4 class="tp-footer-title">Services</h4>
                     <div class="tp-footer-list">
                        <ul>
                           <li><a href="service-details1.php"><i class="fa-sharp fa-solid fa-plus"></i>Automotive Wire Harness</a></li>
                           <li><a href="service-details2.php"><i class="fa-sharp fa-solid fa-plus"></i>EV Charging Solutions</a></li>
                            <li><a href="service-details3.php"><i class="fa-sharp fa-solid fa-plus"></i>Home Appliance Harness</a></li>
                           <li><a href="service-details4.php"><i class="fa-sharp fa-solid fa-plus"></i>Solar & Control Panel Wiring</a></li>
                          <li><a href="service-details5.php"><i class="fa-sharp fa-solid fa-plus"></i>Lighting & Industrial Harness</a></li>
                           <li><a href="service-details6.php"><i class="fa-sharp fa-solid fa-plus"></i>Custom Design & Mass Production</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <!--<div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-50 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".9s">-->
               <!--   <div class="tp-footer-widget footer-cols-4">-->
               <!--      <h4 class="tp-footer-title">Products</h4>-->
               <!--      <div class="tp-footer-thumb-wrap">-->
               <!--         <div class="tp-footer-thumb-box d-flex">-->
               <!--            <div class="tp-footer-thumb p-relative">-->
               <!--               <img src="assets/img/footer/footer-1-1.jpg" alt="">-->
               <!--               <div class="tp-footer-thumb-icon">-->
               <!--                  <a href="#"><i class="fa-brands fa-instagram"></i></a>-->
               <!--               </div>-->
               <!--            </div>-->
               <!--            <div class="tp-footer-thumb p-relative">-->
               <!--               <img src="assets/img/footer/footer-1-2.jpg" alt="">-->
               <!--               <div class="tp-footer-thumb-icon">-->
               <!--                  <a href="#"><i class="fa-brands fa-instagram"></i></a>-->
               <!--               </div>-->
               <!--            </div>-->
               <!--            <div class="tp-footer-thumb p-relative">-->
               <!--               <img src="assets/img/footer/footer-1-3.jpg" alt="">-->
               <!--               <div class="tp-footer-thumb-icon">-->
               <!--                  <a href="#"><i class="fa-brands fa-instagram"></i></a>-->
               <!--               </div>-->
               <!--            </div>-->
               <!--         </div>-->
               <!--         <div class="tp-footer-thumb-box d-flex">-->
               <!--            <div class="tp-footer-thumb p-relative">-->
               <!--               <img src="assets/img/footer/footer-1-4.jpg" alt="">-->
               <!--               <div class="tp-footer-thumb-icon">-->
               <!--                  <a href="#"><i class="fa-brands fa-instagram"></i></a>-->
               <!--               </div>-->
               <!--            </div>-->
               <!--            <div class="tp-footer-thumb p-relative">-->
               <!--               <img src="assets/img/footer/footer-1-5.jpg" alt="">-->
               <!--               <div class="tp-footer-thumb-icon">-->
               <!--                  <a href="#"><i class="fa-brands fa-instagram"></i></a>-->
               <!--               </div>-->
               <!--            </div>-->
               <!--            <div class="tp-footer-thumb p-relative">-->
               <!--               <img src="assets/img/footer/footer-1-6.jpg" alt="">-->
               <!--               <div class="tp-footer-thumb-icon">-->
               <!--                  <a href="#"><i class="fa-brands fa-instagram"></i></a>-->
               <!--               </div>-->
               <!--            </div>-->
               <!--         </div>-->
               <!--      </div>-->
               <!--   </div>-->
               <!--</div>-->
            </div>
         </div>
      </div>
      <!-- footer area end -->

      <!-- copy-right area start -->
      <div class="tp-copyright-area tp-copyright-space black-bg-2">
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                  <div class="tp-copyright-left text-center text-md-start">
                  <p>© Copyright 2026 Chaitra Konnex Technology (CKT). All Rights Reserved.</p>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".5s">
                  <div class="tp-copyright-social text-center text-md-end">
                     <!--<a href="#"><i class="fa-brands fa-facebook-f"></i></a>-->
                     <!--<a href="#"><i class="fa-brands fa-instagram"></i></a>-->
                     <a href="https://www.linkedin.com/company/105155808/admin/page-posts/published/"  target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
                   
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- copy-right area end -->

   </footer>
<script>
    document.getElementById("whatsappForm").addEventListener("submit", function(e){

    e.preventDefault();

    let name = document.getElementById("name").value;
    let mobile = document.getElementById("mobile").value;
    let service = document.getElementById("service").value;

    let message =
`Hello,

Name: ${name}
Mobile: ${mobile}
Service: ${service}`;

    let phone = "+91 9284247921";

    let url = "https://wa.me/" + phone + "?text=" + encodeURIComponent(message);

    window.open(url, "_blank");
});
</script>

   <!-- JS here -->
   
   <script src="assets/js/vendor/jquery.js"></script>
   <script src="assets/js/vendor/waypoints.js"></script>
   <script src="assets/js/bootstrap-bundle.js"></script>
   <script src="assets/js/swiper-bundle.js"></script>
   <script src="assets/js/slick.js"></script>
   <script src="assets/js/range-slider.js"></script>
   <script src="assets/js/magnific-popup.js"></script>
   <script src="assets/js/nice-select.js"></script>
   <script src="assets/js/purecounter.js"></script>
   <script src="assets/js/wow.js"></script>
   <script src="assets/js/isotope-pkgd.js"></script>
   <script src="assets/js/jarallax.js"></script>
   <script src="assets/js/imagesloaded-pkgd.js"></script>
   <script src="assets/js/ajax-form.js"></script>
   <script src="assets/js/main.js"></script>

   
</body>

</html>