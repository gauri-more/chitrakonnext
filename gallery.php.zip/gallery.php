
<?php include 'header.php'; ?>
<style>
    .tp-project-thumb {
    overflow: hidden;
    border-radius: 8px;
}

/*.tp-project-thumb img {*/
/*    width: 100%;*/
    /*height: 350px; */
/*    object-fit: cover;*/
/*    display: block;*/
/*    transition: 0.4s;*/
/*}*/

.tp-project-thumb img {
    width: 100%;
    height: 300px;
    object-fit: contain;
    background: #f5f5f5;
}
.tp-project-thumb:hover img {
    transform: scale(1.05);
}
#modalImage{
    max-height:80vh;
}

.gallery-btn{
    position:absolute;
    top:50%;
    transform:translateY(-50%);
    width:45px;
    height:45px;
    border:none;
    border-radius:50%;
    background:#000;
    color:#fff;
    font-size:22px;
    cursor:pointer;
    z-index:999;
}

.prev-btn{
    left:20px;
}

.next-btn{
    right:20px;
}

#galleryImage{
    max-height:80vh;
}
</style>
   <main>

      <!-- breadcrumb area start -->
      <div class="breadcrumb__area breadcrumb__overlay breadcrumb__height p-relative fix" data-background="assets/Images/breadcurmb.webp">
         <div class="container">
            <div class="row">
               <div class="col-xxl-12">
                  <div class="breadcrumb__content z-index d-flex justify-content-between align-items-end">
                     <div class="breadcrumb__section-title-box">
                        <h4 class="breadcrumb__subtitle">CKT- WIRE HARNESS SERVICE</h4>
                        <h3 class="breadcrumb__title">Gallery</h3>
                     </div>
                     <div class="breadcrumb__list">
                        <span><a href="index.php">Home</a></span>
                        <span class="dvdr"><i>/</i></span>
                        <span>Gallery</span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- breadcrumb area end -->


      <!-- project area start -->
      <div class="tp-project-area p-relative pt-120 pb-90">
         <div class="tp-project-shape-1 d-none d-xl-block">
            <img src="assets/img/project/shape-1-1.png" alt="">
         </div>
         <div class="container">
<div class="row">
    
    <!-- Item 9 -->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/ckt-8.jpg"
                     class="img-fluid"
                     alt="">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/ckt-8.jpg"
                 data-title="Wire Harness Assembly">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Wire Harness Assembly
                    </a>
                </h4>

            </div>

        </div>
    </div>
    
          <!-- Item 8-->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/ckt-2.jpg"
                     class="img-fluid"
                     alt="Automatic Wire Cutting & Stripping Machine">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/ckt-2.jpg"
                 data-title="Automatic Wire Cutting & Stripping Machine">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Automatic Wire Cutting & Stripping Machine
                    </a>
                </h4>

            </div>

        </div>
    </div>
      <!-- Item 2-->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/ckt-4.jpg"
                     class="img-fluid"
                     alt="Automatic Wire Reel Pay-Off (Dereeler) Machine">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/ckt-4.jpg"
                 data-title="Automatic Wire Reel Pay-Off (Dereeler) Machine">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Automatic Wire Reel Pay-Off (Dereeler) Machine
                    </a>
                </h4>

            </div>

        </div>
    </div>
 <!-- Item 3 -->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/gallery/AutomaticWireCutting,StrippingTwistingMachine.jpg"
                     class="img-fluid"
                     alt="Automatic Cutting & Stripping Machine Controller">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/gallery/AutomaticWireCutting,StrippingTwistingMachine.jpg"
                 data-title="Automatic Cutting & Stripping Machine Controller">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Automatic Wire Cutting, Stripping & Twisting Machine
                    </a>
                </h4>

            </div>

        </div>
    </div>
     <!-- Item 4 -->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".7s">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/gallery/AutomaticWireCutStripMachine.jpg"
                     class="img-fluid"
                     alt="Automatic Multi-Core Cable Stripping Machine">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/gallery/AutomaticWireCutStripMachine.jpg"
                 data-title="Automatic Multi-Core Cable Stripping Machine">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                      Automatic Multi-Core Cable Stripping Machine
                    </a>
                </h4>

            </div>

        </div>
    </div>

 <!-- Item 5-->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".7s">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/ckt-6.jpg"
                     class="img-fluid"
                     alt="Raw Material & Spare Parts Inventory">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/ckt-6.jpg"
                 data-title="Raw Material & Spare Parts Inventory">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Raw Material & Spare Parts Inventory
                    </a>
                </h4>

            </div>

        </div>
    </div>

 <!-- Item 6 -->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".7s">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/ckt-7.jpg"
                     class="img-fluid"
                     alt="Cable Assembly & Quality Inspection">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/ckt-7.jpg"
                 data-title="Cable Assembly & Quality Inspection">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Cable Assembly & Quality Inspection
                    </a>
                </h4>

            </div>

        </div>
    </div>

    <!-- Item 7-->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/gallery/machine-JKT-1.jpg"
                     class="img-fluid"
                     alt="Semi-Automatic Terminal Crimping Machine">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/gallery/machine-JKT-1.jpg"
                 data-title="Semi-Automatic Terminal Crimping Machine">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Semi-Automatic Terminal Crimping Machine
                    </a>
                </h4>

            </div>

        </div>
    </div>

    <!-- Item 8 -->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".5s">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/gallery/machine-ckt-1.jpg"
                     class="img-fluid"
                     alt="Digital Load Testing Machine">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/gallery/machine-ckt-1.jpg"
                 data-title="Digital Load Testing Machine for Wire Harness">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Digital Load Testing Machine for Wire Harness
                    </a>
                </h4>

            </div>

        </div>
    </div>

    <!-- Item 1-->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/ckt-3.jpg"
                     class="img-fluid"
                     alt="Shielded Cable Assembly">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/ckt-3.jpg"
                 data-title="Shielded Cable Assembly">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                       Shielded Cable Assembly
                    </a>
                </h4>

            </div>

        </div>
    </div>

    <!-- Item 10 -->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/gallery/CustomCircularConnectorCableAssembly.jpg"
                     class="img-fluid"
                     alt="">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/gallery/CustomCircularConnectorCableAssembly.jpg"
                 data-title="Custom Circular Connector Cable Assembly">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Custom Circular Connector Cable Assembly
                    </a>
                </h4>

            </div>

        </div>
    </div>

   <!-- Item 10 -->
    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp">
        <div class="tp-project-item p-relative">

            <div class="tp-project-thumb">
                <img src="assets/Images/ckt-10.jpg"
                     class="img-fluid"
                     alt="Custom Electrical Wiring Harness">
            </div>

            <div class="tp-project-content open-gallery"
                 data-image="assets/Images/ckt-10.jpg"
                 data-title="Custom Electrical Wiring Harness">

                <a href="javascript:void(0)">
                    <i class="flaticon-right-arrow"></i>
                </a>

                <span>CKT</span>

                <h4 class="tp-project-title">
                    <a href="javascript:void(0)">
                        Custom Electrical Wiring Harness
                    </a>
                </h4>

            </div>

        </div>
    </div>
    <!-- Video Item 1 -->
<div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp ">
    <div class="tp-project-item p-relative">

        <div class="tp-project-thumb">
            <video class="img-fluid" muted autoplay loop playsinline>
                <source src="assets/videos/gallery-video-2.mp4" type="video/mp4">
            </video>
        </div>

        <div class="tp-project-content open-gallery"
             data-type="video"
             data-video="assets/videos/gallery-video-2.mp4"
             data-title="Automatic Multi-Core Cable Stripping Process">

            <a href="javascript:void(0)">
                <i class="flaticon-right-arrow"></i>
            </a>

            <span>CKT</span>

            <h4 class="tp-project-title">
                <a href="javascript:void(0)">
                  Automatic Multi-Core Cable Stripping Process
                </a>
            </h4>

        </div>

    </div>
</div>
     
    <!-- Video Item 2 -->
<div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp ">
    <div class="tp-project-item p-relative">

        <div class="tp-project-thumb">
            <video class="img-fluid" muted autoplay loop playsinline>
                <source src="assets/videos/gallery-video-1.mp4" type="video/mp4">
            </video>
        </div>

        <div class="tp-project-content open-gallery"
             data-type="video"
             data-video="assets/videos/gallery-video-1.mp4"
             data-title=" Wire Harness ">

            <a href="javascript:void(0)">
                <i class="flaticon-right-arrow"></i>
            </a>

            <span>CKT</span>

            <h4 class="tp-project-title">
                <a href="javascript:void(0)">
                   Wire Harness 
                </a>
            </h4>

        </div>

    </div>
</div>
     
    <!-- Video Item 2 -->
<div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp ">
    <div class="tp-project-item p-relative">

        <div class="tp-project-thumb">
            <video class="img-fluid" muted autoplay loop playsinline>
                <source src="assets/videos/gallery-video-3.mp4" type="video/mp4">
            </video>
        </div>

        <div class="tp-project-content open-gallery"
             data-type="video"
             data-video="assets/videos/gallery-video-3.mp4"
             data-title="Automatic Wire Cutting Process">

            <a href="javascript:void(0)">
                <i class="flaticon-right-arrow"></i>
            </a>

            <span>CKT</span>

            <h4 class="tp-project-title">
                <a href="javascript:void(0)">
                 Automatic Wire Cutting Process
                </a>
            </h4>

        </div>

    </div>
</div>
</div>
         </div>
      </div>
      <!-- project area end -->
      <div class="modal fade" id="galleryModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 id="galleryTitle"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body position-relative d-flex justify-content-center align-items-center">

                <!-- Previous Button -->
                <button id="prevBtn" class="gallery-btn prev-btn">
                    &#10094;
                </button>

                <!-- Image -->
                <img id="galleryImage"
                     class="img-fluid rounded"
                     style="display:none; max-height:80vh;">

                <!-- Video -->
                <video id="galleryVideo"
                       class="img-fluid rounded"
                       controls
                       style="display:none; max-height:80vh; width:100%;">
                    <source id="galleryVideoSource" src="" type="video/mp4">
                    Your browser does not support the video tag.
                </video>

                <!-- Next Button -->
                <button id="nextBtn" class="gallery-btn next-btn">
                    &#10095;
                </button>

            </div>

        </div>
    </div>
</div>

   </main>
   <script>
document.addEventListener("DOMContentLoaded", function () {

    const galleryItems = document.querySelectorAll(".open-gallery");
    const galleryModal = new bootstrap.Modal(document.getElementById("galleryModal"));

    const image = document.getElementById("galleryImage");
    const video = document.getElementById("galleryVideo");
    const videoSource = document.getElementById("galleryVideoSource");
    const title = document.getElementById("galleryTitle");

    let currentIndex = 0;

    function showItem(index) {

        currentIndex = index;

        // Stop previous video
        video.pause();
        video.currentTime = 0;
        video.style.display = "none";
        videoSource.src = "";

        image.style.display = "none";

        const item = galleryItems[index];

        title.innerHTML = item.dataset.title;

        if (item.dataset.type === "video") {

            video.style.display = "block";
            videoSource.src = item.dataset.video;
            video.load();
            video.play();

        } else {

            image.style.display = "block";
            image.src = item.dataset.image;

        }
    }

    // Open Gallery
    galleryItems.forEach(function (item, index) {

        item.addEventListener("click", function () {

            showItem(index);
            galleryModal.show();

        });

    });

    // Next Button
    document.getElementById("nextBtn").addEventListener("click", function () {

        currentIndex++;

        if (currentIndex >= galleryItems.length) {
            currentIndex = 0;
        }

        showItem(currentIndex);

    });

    // Previous Button
    document.getElementById("prevBtn").addEventListener("click", function () {

        currentIndex--;

        if (currentIndex < 0) {
            currentIndex = galleryItems.length - 1;
        }

        showItem(currentIndex);

    });

    // Keyboard Navigation
    document.addEventListener("keydown", function (e) {

        if (!document.getElementById("galleryModal").classList.contains("show"))
            return;

        if (e.key === "ArrowRight") {
            document.getElementById("nextBtn").click();
        }

        if (e.key === "ArrowLeft") {
            document.getElementById("prevBtn").click();
        }

    });

    // Stop video when modal closes
    document.getElementById("galleryModal").addEventListener("hidden.bs.modal", function () {

        video.pause();
        video.currentTime = 0;
        videoSource.src = "";
        video.load();

    });

});
</script>

<?php include 'footer.php'; ?>