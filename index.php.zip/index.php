<?php include 'header.php'; ?>
<style>
    .tp-slider-bg{
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    overflow:hidden;
    z-index:-1;
}

.slider-video{
    width:100%;
    height:100%;
    object-fit:cover;
}

.tp-slider-overly{
    position:relative;
    overflow:hidden;
}

.tp-slider-overly::before{
    content:"";
    position:absolute;
    inset:0;
    background:rgba(0,0,0,.35);
    z-index:1;
}

.container.z-index-5{
    position:relative;
    z-index:2;
}
.tp-slider-overly::after {
    position: absolute;
    content: "";
    inset: 0;
    background: transparent;
}
/*.tp-slider-overly::after {*/
/*    background-image: none;*/
/*}*/
/*.tp-brand-6-slide-active .swiper-wrapper{*/
/*    transition-timing-function: linear !important;*/
/*}*/

/*.tp-brand-6-slide-active .swiper-slide{*/
/*    width:auto !important;*/
/*}*/

/*.tp-brand-6-item{*/
/*    display:flex;*/
/*    align-items:center;*/
/*    justify-content:center;*/
/*}*/

/*.tp-brand-6-item img{*/
/*    max-height:70px;*/
/*    width:auto;*/
/*    object-fit:contain;*/
/*}*/
</style>

   <main>

      <!-- hero area start -->
      <div class="tp-slider-area z-index p-relative">
         <div class="tp-slider-arrow-box">
            <button class="slider-prev">
               <i class="fa-regular fa-arrow-left-long"></i>
            </button>
            <button class="slider-next active">
               <i class="fa-regular fa-arrow-right-long"></i>
            </button>
         </div>
         <div class="tp-slider-wrapper">
            <div class="swiper-container tp-slider-active">
               <div class="swiper-wrapper">
                  <div class="swiper-slide">
                     <div class="tp-slider-height tp-slider-overly">
                        <div class="tp-slider-shape-2 d-none d-xl-block">
                           <img src="assets/img/hero/bg-1-2.png" alt="">
                        </div>
                        <div class="tp-slider-shape-3 d-none d-md-block">
                           <img src="assets/img/hero/bg-1-3.png" alt="">
                        </div>
       <div class="tp-slider-bg">
    <video class="slider-video" autoplay muted loop playsinline>
        <source src="assets/videos/ckt-banner-gif.mov" type="video/mp4">
        Your browser does not support the video tag.
    </video>
</div>
                        <!--<div class="tp-slider-bg" data-background="assets/Images/slider-1-1.webp"></div>-->
                        <div class="container z-index-5">
                           <div class="row">
                              <div class="col-xl-8 col-lg-8">
                                 <div class="tp-slider-content">
                                    <div class="tp-slider-title-box">
    <h1 class="tp-slider-title">
        Precision <br>
        Wire Harness & <br>
        Interconnect <span>Solutions</span>
    </h1>
</div>

<div class="tp-slider-text">
    <p>
        Chaitra Konnex Technology (CKT) delivers high-quality wire harness assemblies and
        custom interconnect solutions for automotive, industrial, electrical, and electronic
        applications with precision, reliability, and innovation.
    </p>
    <a class="tp-btn" href="assets/pdf/Chaitra-Konnex-Technology-Company-Brochure.pdf" download>
    <span><i class="fa-solid fa-download me-2"></i>Download Company Brochure</span>
</a>
    <!--<a class="tp-btn" href="about-us.php">-->
    <!--    <span>Discover More</span>-->
    <!--</a>-->
</div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-slider-height tp-slider-overly">
                        <div class="tp-slider-shape-2 d-none d-xl-block">
                           <img src="assets/img/hero/bg-1-2.png" alt="">
                        </div>
                        <div class="tp-slider-shape-3 d-none d-md-block">
                           <img src="assets/img/hero/bg-1-3.png" alt="">
                        </div>
                          <div class="tp-slider-bg">
    <video class="slider-video" autoplay muted loop playsinline>
        <source src="assets/videos/ckt-banner-gif.mov" type="video/mp4">
        Your browser does not support the video tag.
    </video>
</div>
                          <!--<div class="tp-slider-bg" data-background="assets/Images/slider-1-1.webp"></div>-->
                        <div class="container z-index-5">
                           <div class="row">
                              <div class="col-xl-8 col-lg-8">
                                 <div class="tp-slider-content z-index-5">
                                    <div class="tp-slider-title-box">
    <h1 class="tp-slider-title">
        Engineering <br>
        Excellence <br>
        <span>Everyday</span>
    </h1>
</div>

<div class="tp-slider-text">
    <p>
        We transform ideas into high-quality products with expertise in wire harnesses,
        industrial manufacturing, painting, and customized engineering solutions.
    </p>
   <a class="tp-btn" href="assets/pdf/Chaitra-Konnex-Technology-Company-Brochure.pdf" download>
    <span><i class="fa-solid fa-download me-2"></i>Download Company Brochure</span>
</a>
</div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-slider-height tp-slider-overly">
                        <div class="tp-slider-shape-2 d-none d-xl-block">
                           <img src="assets/img/hero/bg-1-2.png" alt="">
                        </div>
                        <div class="tp-slider-shape-3 d-none d-md-block">
                           <img src="assets/img/hero/bg-1-3.png" alt="">
                        </div>
<!--                                       <div class="tp-slider-bg">-->
<!--    <video class="slider-video" autoplay muted loop playsinline>-->
<!--        <source src="assets/videos/banner-slider.mp4" type="video/mp4">-->
<!--        Your browser does not support the video tag.-->
<!--    </video>-->
<!--</div>-->
                       <!--<div class="tp-slider-bg" data-background="assets/Images/ckt-2.jpg"></div>-->
                                          <div class="tp-slider-bg">
    <video class="slider-video" autoplay muted loop playsinline>
        <source src="assets/videos/ckt-banner-gif.mov" type="video/mp4">
        Your browser does not support the video tag.
    </video>
</div>
                        <div class="container z-index-5">
                           <div class="row">
                              <div class="col-xl-8 col-lg-8">
                                 <div class="tp-slider-content">
          <div class="tp-slider-title-box">
    <h1 class="tp-slider-title">
        Your <br>
        First Choice for <br>
        <span>Interconnect Solutions</span>
    </h1>
</div>

<div class="tp-slider-text">
    <p>
        Delivering advanced automotive electrical, electronic, and interconnect solutions
        engineered for demanding applications with exceptional quality, reliability, and innovation.
    </p>
   <a class="tp-btn" href="assets/pdf/Chaitra-Konnex-Technology-Company-Brochure.pdf" download>
    <span><i class="fa-solid fa-download me-2"></i>Download Company Brochure</span>
</a>
</div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- hero area end -->
      <div class="tp-feature-2-area p-relative">
    <div class="tp-feature-2-bg pt-60 pb-30" data-background="assets/img/feature/bg-1.png">
        <div class="container">
            <div class="row">

                <!-- Experience -->
                <div class="col-xl-3 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                    <div class="tp-feature-2-item">
                       <div class="tp-feature-2-icon">
    <span><i class="fa-solid fa-award"></i></span>
</div>

                        <div class="tp-feature-2-text">
                            <h5 class="tp-feature-2-title">5+ Years of Industry Experience</h5>
                        </div>
                    </div>
                </div>

                <!-- Facility -->
                <div class="col-xl-3 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".5s">
                    <div class="tp-feature-2-item">
                        <div class="tp-feature-2-icon">
    <span><i class="fa-solid fa-industry"></i></span>
</div>
                        <div class="tp-feature-2-text">
                            <h5 class="tp-feature-2-title">2000 Sq.ft Manufacturing Facility</h5>
                        </div>
                    </div>
                </div>

                <!-- ISO -->
                <div class="col-xl-3 col-lg-4 col-md-6 mb-30 wow tpfadeUp active" data-wow-duration=".9s" data-wow-delay=".7s">
                    <div class="tp-feature-2-item active">
                        <div class="tp-feature-2-icon">
    <span><i class="fa-solid fa-certificate"></i></span>
</div>
                        <div class="tp-feature-2-text">
                            <h5 class="tp-feature-2-title">ISO 9001:2015 Quality System</h5>
                        </div>
                    </div>
                </div>

                <!-- Prototype -->
                <div class="col-xl-3 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".9s">
                    <div class="tp-feature-2-item">
                       <div class="tp-feature-2-icon">
    <span><i class="fa-solid fa-gears"></i></span>
</div>
                        <div class="tp-feature-2-text">
                            <h5 class="tp-feature-2-title">Prototype to Production Capability</h5>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
        <!-- about area start -->
      <div class="tp-about-4-area pt-60 pb-70 d-none">
         <div class="container">
            <div class="row">
               <div class="col-xl-6 col-lg-6 mb-50 wow tpfadeLeft" data-wow-duration=".9s" data-wow-delay=".3s">
                  <div class="tp-about-4-left-box">
                     <div class="tp-about-4-section-box mb-30">
                        <span class="tp-section-subtitle">ABOUT CKT</span>
                        <h4 class="tp-section-title">Your Trusted Partner for Wire Harness & Electrical Connectivity Solutions</h4>
                     </div>
                     <div class="tp-about-4-text pb-15">
                        <p>  CKT is committed to delivering innovative automotive electrical,
        electronic, and interconnect solutions that meet the highest standards
        of quality, performance, and reliability for demanding applications.</p>
                     </div>
           <div class="tp-about-4__progress pb-55">

    <div class="tp-about-4__progress-item mb-25 fix">
        <h4>Wiring Accuracy</h4>
        <span class="progress-count">99%</span>
        <div class="progress">
            <div class="progress-bar" role="progressbar" data-width="99%"
                aria-valuenow="99" aria-valuemin="0" aria-valuemax="100"
                style="width:99%;">
            </div>
        </div>
    </div>

    <div class="tp-about-4__progress-item mb-25 fix">
        <h4>Quality Assurance</h4>
        <span class="progress-count">100%</span>
        <div class="progress">
            <div class="progress-bar" role="progressbar" data-width="100%"
                aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"
                style="width:100%;">
            </div>
        </div>
    </div>

    <div class="tp-about-4__progress-item fix">
        <h4>On-Time Delivery</h4>
        <span class="progress-count">98%</span>
        <div class="progress">
            <div class="progress-bar" role="progressbar" data-width="98%"
                aria-valuenow="98" aria-valuemin="0" aria-valuemax="100"
                style="width:98%;">
            </div>
        </div>
    </div>

</div>
                     <a class="tp-btn-black" href="about-us.php"><span>KNOW MORE</span></a>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 mb-50 wow tpfadeRight" data-wow-duration=".9s" data-wow-delay=".5s">
                  <div class="tp-about-4-right-box">
                     <div class="tp-about-4-thumb mb-30">
                        <img src="assets/Images/ckt-1.jpg" alt="">
                     </div>
                     <div class="tp-about-4-content d-flex align-items-center justify-content-between mr-0">
                        <div class="tp-about-4-mission-box">
                           <h4><i class="flaticon-mission"></i>Our Mission</h4>
                           <p>  Deliver innovative, reliable, and high-quality
                wire harness and interconnect solutions that
                exceed customer expectations.</p>
                        </div>
                        <div class="tp-about-4-mission-box">
                           <h4><i class="flaticon-lamp"></i>Our Vission</h4>
                           <p>To be the first choice in automotive electrical,
                electronics, and interconnect solutions for
                demanding and advanced applications. </p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about area end -->

      <!-- about area start -->
      <div class="tp-about-area p-relative pt-60 pb-60  d-none">
         <div class="tp-about-shape-3">
            <img src="assets/img/about/shape-1-4.png" alt="">
         </div>
         <div class="tp-about-shape-4 d-none d-xl-block">
            <img src="assets/img/about/shape-1-5.png" alt="">
         </div>
         <div class="container">
            <div class="row">
               <div class="col-xl-8 col-lg-8 wow tpfadeLeft" data-wow-duration=".9s" data-wow-delay=".5s">
                  <div class="tp-about-left-box">
                     <div class="tp-about-section-box mb-15">
                           <span class="tp-section-subtitle">
        <i class="flaticon-flash"></i> ABOUT CKT
    </span>

 <h4 class="tp-section-title">
    Engineering Reliable Connections for a Smarter Tomorrow
</h4>
</div>

<div class="tp-about-text">
     <p>
        Established in <strong>2021</strong>, <strong>Chaitra Konnex Technology (CKT)</strong> is a leading manufacturer and supplier of high-quality wiring harnesses, cable assemblies, and electrical interconnect solutions. Since our inception, we have earned the trust of customers by delivering reliable, precision-engineered products that meet the evolving needs of industries such as <strong>Automotive, Electric Vehicles (EV), Military &amp; Defense, Industrial Automation, Home Appliances, Renewable Energy, and Electronics.</strong>
    </p>

    <p>
        At Chaitra Konnex Technology, quality, innovation, and customer satisfaction are at the heart of everything we do. Our products are manufactured using advanced production technologies, premium-grade materials, and stringent quality control processes to ensure exceptional performance, durability, and long-term reliability. From customized wiring harnesses and complex cable assemblies to high-volume production requirements, we work closely with our customers to develop solutions tailored to their exact specifications.
    </p>


    <div class="tp-about-icon-wrap p-relative d-flex justify-content-between mb-45">
        <div class="tp-about-icon-shape d-none d-xl-block">
            <!--<img src="assets/img/about/shape-1-6.png" alt="">-->
        </div>

    <div class="tp-about-4-content d-flex align-items-center justify-content-between d-none">

        <div class="tp-about-4-mission-box" style="box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;padding: 1em;
    margin: 0.5em;">
            <h4><i class="flaticon-mission"></i>Our Mission</h4>
            <p>
                Deliver innovative, reliable, and high-quality
                wire harness and interconnect solutions that
                exceed customer expectations.
            </p>
        </div>

        <div class="tp-about-4-mission-box" style="box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;padding: 1em;
    margin: 0.5em;">
            <h4><i class="flaticon-lamp"></i>Our Vision</h4>
            <p>
                To be the first choice in automotive electrical,
                electronics, and interconnect solutions for
                demanding and advanced applications.
            </p>
        </div>

    </div>
</div>
                        <div class="tp-about-button-box d-flex align-items-center">
                           <a class="tp-btn-black" href="about-us.php"><span>KNOW MORE</span></a>
                           <!--<img src="assets/img/about/shape-1-1.png" alt="">-->
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-4 col-lg-4 wow tpfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
                  <div class="tp-about-right-box p-relative text-end">
                     <div class="tp-about-main-thumb">
                        <img src="assets/Images/about-wire-harness.jpg" alt="">
                     </div>
                     <!--<div class="tp-about-thumb-sm">-->
                     <!--   <img src="assets/Images/about-wire-harness-2.jpeg" alt="">-->
                     <!--</div>-->
                     <!--<div class="tp-about-shape-1 d-none d-lg-block">-->
                     <!--   <img src="assets/img/about/shape-1-2.png" alt="">-->
                     <!--</div>-->
                     <div class="tp-about-shape-2  d-none d-lg-block">
                        <!--<img src="assets/img/about/shape-1-3.png" alt="">-->
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about area end -->
       <!-- about area start -->
      <div class="tp-about-area p-relative pt-60 pb-60">
         <div class="tp-about-shape-5 d-none d-xl-block">
            <img src="assets/img/about/shape-3-1.png" alt="">
         </div>
         <div class="container">
            <div class="row">
               <div class="col-xl-5 col-lg-5 wow tpfadeLeft" data-wow-duration=".9s" data-wow-delay=".5s">
                  <div class="tp-about-right-box text-end tp-about-right-wrap p-relative">
                     <div class="tp-about-2-thumb-text text-start d-none d-lg-block" data-background="assets/img/about/bg-1.jpg">
                        <h6><i class="purecounter" data-purecounter-duration="1" data-purecounter-end="5">0</i>+</h6>
                        <span>Years of experience</span>
                     </div>
                     <div class="tp-about-main-thumb">
                        <img src="assets/Images/wire-harness-about.jpeg" alt="">
                     </div>
                     <div class="tp-about-thumb-sm">
                        <img src="assets/Images/about-wire-harness-re.png" alt="">
                     </div>
                     <div class="tp-about-shape-2  d-none d-lg-block">
                        <img src="assets/img/about/shape-1-3.png" alt="">
                     </div>
                     <div class="tp-about-shape-6 d-none d-xl-block">
                        <img src="assets/img/about/shape-3-2.png" alt="">
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7 wow tpfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
                  <div class="tp-about-left-box tp-about-ml">
                     <div class="tp-about-section-box mb-15">
                                       <span class="tp-section-subtitle">
        <i class="flaticon-flash"></i> ABOUT CKT
    </span>
                         <h4 class="tp-section-title">
   Your Trusted Partner for Wire Harness & Electrical Connectivity Solutions
</h4>
                     </div>
                     <div class="tp-about-text me-0">
                     <p class="">
                         Chaitra Konnex Technology (CKT) is an Indian manufacturer known for delivering high-performance wire harness solutions and strategic partner for customized wire harness assemblies, electrical interconnect solutions for Defence, Automotive, EV, Industrial and Renewable Energy applications.

                     </p>
                                <p class="pb-15">
        Established in <strong>2021</strong>, <strong>Chaitra Konnex Technology (CKT)</strong> is a leading manufacturer and supplier of high-quality wiring harnesses, cable assemblies, and electrical interconnect solutions. Since our inception, we have earned the trust of customers by delivering reliable, precision-engineered products that meet the evolving needs of industries such as <strong>Automotive, Electric Vehicles (EV), Military &amp; Defense, Industrial Automation, Home Appliances, Renewable Energy, and Electronics.</strong>
    </p>

    
                       
                        <div class="tp-about-button-box d-flex align-items-center">
                           <a class="tp-btn-black" href="about-us.php"><span>KNOW MORE</span></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about area end -->

        <!-- tp-feature-area-start -->
      <div class="tp-feature-area body-bg-6 p-relative z-index-1 pt-60">
         <img class="tp-feature-6-shape" src="assets/img/update/feature/shape.png" alt="">
         <img class="tp-feature-6-shape-2" src="assets/Images/shape-2.webp" alt="">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <div class="text-center mb-75 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                     <h3 class="tp-section-title tp-section-6-title">Building Trust Through Our Values</h3>
                  </div>
               </div>
               <div class="col-lg-4 col-md-6">
                  <div class="tp-feature-6-item wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                     <!--<span class="tp-feature-6-icon mb-25 d-inline-block">-->
                     <!--   <svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg">-->
                     <!--      <path d="M46.9165 40.4327C47.9437 39.0204 48.5004 37.3206 48.5077 35.5743C48.5188 35.3446 48.4382 35.12 48.2836 34.9498C48.129 34.7797 47.9132 34.6779 47.6835 34.6669C47.2072 34.6491 46.8041 35.0153 46.7761 35.4911C46.7827 36.8751 46.3563 38.2266 45.5568 39.3564C43.8659 41.4918 40.6576 41.6001 40.031 41.6001C39.5523 41.6001 39.1643 41.9881 39.1643 42.4668C39.1643 42.9454 39.5523 43.3334 40.031 43.3334C40.7971 43.3334 44.7291 43.1939 46.9165 40.4327Z" fill="#5A00A3" />-->
                     <!--      <path d="M29.4662 29.467C29.4662 28.9884 29.0782 28.6004 28.5996 28.6004C28.1209 28.6004 27.7329 28.9884 27.7329 29.467C27.7329 31.3816 29.285 32.9336 31.1995 32.9336V33.8003C31.1995 34.2789 31.5875 34.6669 32.0662 34.6669C32.5448 34.6669 32.9328 34.2789 32.9328 33.8003V32.9336C34.8474 32.9336 36.3995 31.3816 36.3995 29.467C36.3995 27.5524 34.8474 26.0004 32.9328 26.0004V22.5338C33.8901 22.5338 34.6662 23.3098 34.6662 24.2671C34.6662 24.7457 35.0542 25.1337 35.5328 25.1337C36.0115 25.1337 36.3995 24.7457 36.3995 24.2671C36.3995 22.3525 34.8474 20.8005 32.9328 20.8005V19.9338C32.9328 19.4552 32.5448 19.0671 32.0662 19.0671C31.5875 19.0671 31.1995 19.4552 31.1995 19.9338V20.8005C29.285 20.8005 27.7329 22.3525 27.7329 24.2671C27.7329 26.1816 29.285 27.7337 31.1995 27.7337V31.2003C30.2423 31.2003 29.4662 30.4243 29.4662 29.467ZM29.4662 24.2671C29.4662 23.3098 30.2423 22.5338 31.1995 22.5338V26.0004C30.2423 26.0004 29.4662 25.2244 29.4662 24.2671ZM32.9328 27.7337C33.8901 27.7337 34.6662 28.5097 34.6662 29.467C34.6662 30.4243 33.8901 31.2003 32.9328 31.2003V27.7337Z" fill="#5A00A3" />-->
                     <!--      <path d="M51.2748 29.2685C49.1394 20.1937 44.3918 14.9357 40.9634 12.1893C45.2628 12.5134 46.6469 14.3022 46.6876 14.3559C46.9591 14.7435 47.4914 14.8417 47.8833 14.5764C48.2752 14.3111 48.3818 13.7805 48.1228 13.3844C48.0604 13.2908 46.8566 11.5714 43.3562 10.7844C44.2513 10.0486 44.7808 8.95895 44.8061 7.80055C44.6902 5.87999 43.3532 4.2514 41.492 3.76367C41.5683 3.13764 41.6071 2.50761 41.6081 1.87696C41.6072 1.29595 41.3153 0.754054 40.8305 0.433703C40.3458 0.113351 39.7329 0.0571589 39.198 0.284043C38.7604 0.482139 38.3541 0.742845 37.9916 1.05797C37.5663 1.49504 36.9808 1.73926 36.3709 1.73396C35.7621 1.73824 35.1778 1.49413 34.7529 1.05797C33.2256 -0.352656 30.8706 -0.352656 29.3432 1.05797C28.9179 1.49599 28.3314 1.74034 27.7209 1.73396C27.1121 1.73902 26.5278 1.49476 26.1037 1.05797C25.7422 0.743521 25.337 0.483129 24.9008 0.284909C24.3662 0.0595462 23.7544 0.116506 23.2707 0.436668C22.787 0.756829 22.4955 1.29774 22.4941 1.87782C22.4941 4.03406 22.9204 7.88028 25.6201 10.4629C24.2013 11.3256 22.8763 12.3338 21.6664 13.4711V6.93389C21.6664 4.95792 18.8714 3.46727 15.1665 3.46727C11.4615 3.46727 8.66656 4.95792 8.66656 6.93389V15.6655C5.6272 15.9688 3.46662 17.3338 3.46662 19.0671V41.1105C1.37278 41.6729 0 42.8134 0 44.2001V48.5334C0 50.5094 2.79497 52 6.49992 52C9.81314 52 12.3932 50.8066 12.9019 49.14C14.3979 49.9321 16.0746 50.3204 17.7664 50.2667C21.4714 50.2667 24.2664 48.776 24.2664 46.8001V35.5335C24.2664 33.5576 21.4714 32.0669 17.7664 32.0669C17.3323 32.0666 16.8984 32.0883 16.4665 32.1319V19.0671C16.4665 17.1691 13.8864 15.7235 10.3999 15.6117V9.33366C11.8743 10.0831 13.5133 10.4499 15.1665 10.4005C16.8196 10.4499 18.4587 10.0831 19.9331 9.33366V15.2443C19.362 15.883 18.7882 16.5789 18.2223 17.3502C17.9632 17.7361 18.0546 18.2578 18.4296 18.5325C18.8046 18.8072 19.3295 18.7372 19.6194 18.3738C20.176 17.6202 20.7725 16.8969 21.4064 16.2071C21.4133 16.1993 21.4194 16.1915 21.4263 16.1846C23.0807 14.346 25.0235 12.789 27.1783 11.5748C27.6032 11.7798 28.0526 11.9292 28.5156 12.0194L26.2813 14.1046C25.9315 14.4315 25.9128 14.9802 26.2397 15.3301C26.5667 15.6799 27.1153 15.6986 27.4652 15.3717L30.9318 12.1382H31.2083V14.7381C31.2083 15.2168 31.5963 15.6048 32.0749 15.6048C32.5536 15.6048 32.9416 15.2168 32.9416 14.7381V12.1338H33.2181L36.6847 15.3673C36.911 15.5788 37.233 15.6535 37.5293 15.5632C37.8256 15.4729 38.0512 15.2314 38.1212 14.9297C38.1912 14.6279 38.0949 14.3117 37.8685 14.1003L35.6196 12.0064C36.0798 11.9153 36.5263 11.7653 36.9481 11.5601C39.2387 12.7994 46.7682 17.696 49.5883 29.6654C50.8146 34.8757 50.3726 38.8615 48.2753 41.5091C45.5922 44.8934 40.9365 45.0668 40.0308 45.0668H27.733C27.2543 45.0668 26.8663 45.4548 26.8663 45.9334C26.8663 46.4121 27.2543 46.8001 27.733 46.8001H40.0308C41.5042 46.8001 46.5351 46.4959 49.6334 42.5855C52.0756 39.5011 52.6285 35.0205 51.2748 29.2685ZM6.49992 42.4668C9.36595 42.4668 11.2665 43.5068 11.2665 44.2001C11.2665 44.8934 9.36595 45.9334 6.49992 45.9334C3.63389 45.9334 1.73331 44.8934 1.73331 44.2001C1.73331 43.5068 3.63389 42.4668 6.49992 42.4668ZM6.49992 50.2667C3.63389 50.2667 1.73331 49.2267 1.73331 48.5334V46.5999C3.20769 47.3493 4.84676 47.7161 6.49992 47.6667C8.15308 47.7161 9.79215 47.3493 11.2665 46.5999V48.5334C11.2665 49.2267 9.36595 50.2667 6.49992 50.2667ZM17.7664 48.5334C14.9004 48.5334 12.9998 47.4934 12.9998 46.8001V37.9333C14.4742 38.6827 16.1133 39.0495 17.7664 39.0002C19.4196 39.0495 21.0587 38.6827 22.5331 37.9333V46.8001C22.5331 47.4934 20.6325 48.5334 17.7664 48.5334ZM22.5331 35.5335C22.5331 36.2269 20.6325 37.2668 17.7664 37.2668C14.9004 37.2668 12.9998 36.2269 12.9998 35.5335C12.9998 34.8402 14.9004 33.8002 17.7664 33.8002C20.6325 33.8002 22.5331 34.8402 22.5331 35.5335ZM11.2665 35.5335V41.8003C9.79215 41.0509 8.15308 40.6841 6.49992 40.7335C6.06577 40.7332 5.63189 40.7549 5.19994 40.7985V21.4668C6.67432 22.2162 8.31338 22.5831 9.96654 22.5337C11.6197 22.5831 13.2588 22.2162 14.7332 21.4668V32.4439C12.6393 33.0064 11.2665 34.1469 11.2665 35.5335ZM14.7332 19.0671C14.7332 19.7604 12.8326 20.8004 9.96654 20.8004C7.10051 20.8004 5.19994 19.7604 5.19994 19.0671C5.19994 18.3738 7.10051 17.3338 9.96654 17.3338C12.8326 17.3338 14.7332 18.3738 14.7332 19.0671ZM15.1665 8.6672C12.3004 8.6672 10.3999 7.62722 10.3999 6.93389C10.3999 6.24057 12.3004 5.20058 15.1665 5.20058C18.0325 5.20058 19.9331 6.24057 19.9331 6.93389C19.9331 7.62722 18.0325 8.6672 15.1665 8.6672ZM43.0728 7.80055C43.0728 9.221 41.5345 10.3867 39.6062 10.4005C39.2836 10.3985 38.9623 10.3616 38.6477 10.2905C39.9055 8.94848 40.7798 7.29328 41.1792 5.49784C42.2224 5.80522 42.9727 6.71763 43.0728 7.80055ZM25.0186 2.40995C25.7505 3.09577 26.7179 3.47427 27.7209 3.46727C28.7244 3.4748 29.6925 3.09626 30.4248 2.40995C30.8532 1.97744 31.4367 1.7341 32.0455 1.7341C32.6542 1.7341 33.2377 1.97744 33.6661 2.40995C34.3984 3.09677 35.367 3.47538 36.3709 3.46727C37.3748 3.47503 38.3433 3.09646 39.0758 2.40995C39.316 2.19769 39.5832 2.01817 39.8705 1.87609C39.8705 3.48547 39.5715 7.46429 36.7791 9.64566C36.1509 10.1175 35.3894 10.3781 34.6038 10.3901C35.3541 9.1015 35.9479 7.72796 36.3727 6.29864C36.4557 6.00015 36.3731 5.68008 36.1561 5.45898C35.9391 5.23787 35.6206 5.14934 35.3206 5.22671C35.0207 5.30409 34.7847 5.53563 34.7018 5.83411C34.2218 7.46321 33.4839 9.00489 32.5161 10.4005H31.6251C30.6593 9.00366 29.9212 7.46235 29.4386 5.83411C29.3101 5.37294 28.832 5.10327 28.3708 5.23178C27.9097 5.3603 27.64 5.83833 27.7685 6.2995C28.1937 7.73006 28.7881 9.10476 29.5391 10.3945C28.7378 10.3903 27.9592 10.1281 27.3187 9.64653C24.5264 7.46602 24.2274 3.4872 24.2274 1.88302C24.5146 2.02062 24.7809 2.19801 25.0186 2.40995Z" fill="#5A00A3" />-->
                     <!--      <path d="M46.9165 40.4328C47.9437 39.0204 48.5004 37.3207 48.5077 35.5743C48.5188 35.3447 48.4382 35.1201 48.2836 34.9499C48.129 34.7797 47.9132 34.6779 47.6835 34.6669C47.2076 34.6501 46.805 35.0158 46.7761 35.4911C46.7827 36.8752 46.3563 38.2267 45.5568 39.3564C43.8659 41.4919 40.6576 41.6002 40.031 41.6002C39.5523 41.6002 39.1643 41.9882 39.1643 42.4668C39.1643 42.9455 39.5523 43.3335 40.031 43.3335C40.7971 43.3335 44.7291 43.194 46.9165 40.4328Z" fill="#5A00A3" />-->
                     <!--   </svg>-->
                     <!--</span>-->
                     <span class="tp-feature-6-icon mb-25 d-inline-block">
    <i class="fas fa-eye"></i>
</span>
                  <h3 class="tp-feature-6-title">
    <a href="#">Transparency</a>
</h3>

<p>
    We maintain openness and accountability by sharing
    accurate information and building trust with our
    customers, employees, and partners.
</p>
                  </div>
               </div>
               <div class="col-lg-4 col-md-6">
                  <div class="tp-feature-6-item wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".5s">
                     <span class="tp-feature-6-icon mb-25 d-inline-block"><i class="fas fa-shield-alt"></i>
                        <!--<svg width="55" height="52" viewBox="0 0 55 52" fill="none" xmlns="http://www.w3.org/2000/svg">-->
                        <!--   <path d="M54.1796 25.0378L49.5489 18.7533L49.6021 10.9461C49.6073 10.2352 49.148 9.60389 48.47 9.38917L41.0273 7.03221L36.488 0.679553C36.0735 0.0989609 35.3293 -0.140451 34.6546 0.0839511L27.2477 2.55642L19.8409 0.0833124C19.1655 -0.141196 18.4214 0.0982157 18.0074 0.678914L13.4687 7.03093L6.02556 9.38917C5.34756 9.60325 4.88832 10.2352 4.89343 10.9455L4.94666 18.7526L0.315765 25.0372C-0.105255 25.6093 -0.105255 26.3898 0.315765 26.962L4.94655 33.2466L4.89333 41.0537C4.88811 41.7647 5.34745 42.3959 6.02545 42.6106L13.468 44.9676L18.0073 51.3203C18.318 51.7549 18.8137 51.9995 19.3269 51.9995C19.4988 51.9995 19.6714 51.9723 19.8407 51.9159L27.2476 49.4434L34.6545 51.9165C35.3292 52.1417 36.0739 51.901 36.4879 51.3209L41.0266 44.9689L48.47 42.6108C49.148 42.3967 49.6072 41.7648 49.6021 41.0544L49.5489 33.2467L54.1796 26.9621C54.6007 26.3905 54.6007 25.6094 54.1796 25.0378ZM46.6171 31.7564C46.4095 32.0386 46.2985 32.3799 46.3011 32.7296L46.3498 39.8796L39.5313 42.0393C39.1965 42.145 38.9052 42.3565 38.7015 42.6427L34.5456 48.4601L27.7614 46.1953C27.428 46.0838 27.0673 46.0838 26.7339 46.1953L19.9498 48.4601L15.7931 42.6421C15.5894 42.3565 15.2975 42.1445 14.9633 42.038L8.14545 39.879L8.1941 32.729C8.19665 32.3793 8.08573 32.0381 7.87815 31.7558L3.63612 25.9999L7.87772 20.2435C8.08531 19.9613 8.19623 19.62 8.19367 19.2703L8.14503 12.1203L14.9635 9.96061C15.2983 9.8549 15.5896 9.64338 15.7933 9.35724L19.9492 3.53982L26.7333 5.8046C27.0667 5.91616 27.4275 5.91616 27.7609 5.8046L34.545 3.53982L38.7017 9.35788C38.9054 9.64338 39.1973 9.85544 39.5315 9.96189L46.3493 12.121L46.3007 19.2709C46.2981 19.6206 46.409 19.9618 46.6166 20.2441L50.8595 25.9999L46.6171 31.7564Z" fill="#5A00A3" />-->
                        <!--   <path d="M35.2243 18.7709L24.2071 29.7887L19.272 24.8536C18.6381 24.2197 17.6118 24.2197 16.9785 24.8536C16.3454 25.4874 16.3447 26.5137 16.9785 27.147L23.0607 33.2291C23.3773 33.5457 23.7925 33.704 24.2077 33.704C24.623 33.704 25.0375 33.5457 25.3548 33.2291L37.519 21.0649C38.1528 20.4311 38.1528 19.4048 37.519 18.7715C36.8852 18.1382 35.8575 18.1377 35.2243 18.7709Z" fill="#5A00A3" />-->
                        <!--</svg>-->
                     </span>
                     <h3 class="tp-feature-6-title">
    <a href="#">Reliability</a>
</h3>

<p>
    We keep our promises by delivering high-quality,
    dependable solutions that meet customer requirements
    with consistency and excellence.
</p>
                  </div>
               </div>
               <div class="col-lg-4 col-md-6">
                  <div class="tp-feature-6-item wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".7s">
                     <span class="tp-feature-6-icon mb-25 d-inline-block">   <i class="fas fa-balance-scale"></i>
                        <!--<svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg">-->
                        <!--   <path d="M9.7697 9.7697C14.105 5.43441 19.869 3.04688 26 3.04688C30.6885 3.04688 35.2215 4.47312 39.0336 7.10602L36.0906 7.40787L36.4015 10.4388L44.3234 9.6263L43.5109 1.70442L40.4799 2.0153L40.7433 4.58392C36.4292 1.61048 31.3024 0 26 0C19.0552 0 12.526 2.70451 7.61526 7.61526C2.70451 12.526 0 19.0552 0 26C0 31.1992 1.52994 36.2177 4.42437 40.5128L6.95104 38.8101C6.916 38.758 6.88198 38.7055 6.84734 38.6532C4.36089 34.8978 3.04688 30.5273 3.04688 26C3.04688 19.8691 5.43441 14.105 9.7697 9.7697Z" fill="#5A00A3" />-->
                        <!--   <path d="M47.5756 11.4872L45.0489 13.1899C45.0839 13.2419 45.1179 13.2946 45.1526 13.3468C47.6389 17.1022 48.953 21.4727 48.953 26C48.953 32.131 46.5655 37.895 42.2302 42.2303C37.895 46.5656 32.131 48.9531 25.9999 48.9531C21.3114 48.9531 16.7784 47.5268 12.9663 44.8939L15.9093 44.5921L15.5984 41.5612L7.67651 42.3737L8.48901 50.2955L11.52 49.9847L11.2566 47.416C15.5709 50.3895 20.6976 52 25.9999 52C32.9448 52 39.4739 49.2955 44.3848 44.3847C49.2955 39.4739 51.9999 32.9448 51.9999 26C51.9999 20.8008 50.4701 15.7823 47.5756 11.4872Z" fill="#5A00A3" />-->
                        <!--   <path d="M12.6935 29.1976L14.6659 27.3747C16.1601 26 16.444 25.0736 16.444 24.0575C16.444 22.1151 14.7854 20.8749 12.3798 20.8749C10.3178 20.8749 8.83851 21.7415 8.04663 23.0564L10.2431 24.2817C10.6615 23.6093 11.3488 23.2657 12.1109 23.2657C13.0074 23.2657 13.4556 23.6691 13.4556 24.3415C13.4556 24.7749 13.3361 25.253 12.4993 26.03L8.58451 29.6908V31.5436H16.7279V29.1977L12.6935 29.1976Z" fill="#5A00A3" />-->
                        <!--   <path d="M26.1273 29.5413H27.6812V27.1954H26.1273V25.4174H23.3331V27.1954H21.2113L25.4698 21.0841H22.4066L17.7148 27.6138V29.5413H23.2434V31.5435H26.1273V29.5413Z" fill="#5A00A3" />-->
                        <!--   <path d="M30.371 33.0376L35.3017 18.9623H32.7766L27.8457 33.0376H30.371Z" fill="#5A00A3" />-->
                        <!--   <path d="M37.8121 25.0437V23.43H40.5614L37.0352 31.5435H40.2626L43.9533 22.9369V21.0841H35.2869V25.0437H37.8121Z" fill="#5A00A3" />-->
                        <!--</svg>-->
                     </span>
                     <h3 class="tp-feature-6-title">
    <a href="#">Integrity</a>
</h3>

<p>
    We uphold the highest ethical standards, conduct our
    business with honesty, and build lasting relationships
    based on trust and accountability.
</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- tp-feature-area-end -->
<section class="tp-project-area pt-60 pb-60 roadmap-section">
<div class="section-title text-center  pb-70 ">
            <span>CKT Journey</span>
            <h2>History & Milestones</h2>
            <p>Our journey of continuous growth, innovation, and manufacturing excellence.</p>
        </div>
    <!-- Center Road Line -->
    <div class="road-line"></div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="swiper-container tp-project-active">
                    <div class="swiper-wrapper">

                        <!-- 2022 -->
                        <div class="swiper-slide">
                            <div class="journey-card top">

                                <span class="road-dot"></span>

                                <div class="year">2022</div>

                                <div class="icon">
                                    <i class="fas fa-building"></i>
                                </div>

                                <h4>Company Registration</h4>

                                <p>
                                    Company registered with GST, IEC & FF International account.
                                    Started operations from a shared office of 100 sq.ft.
                                </p>

                                <div class="revenue">
                                    Revenue : ₹14 Lakhs
                                </div>

                            </div>
                        </div>

                        <!-- 2023 -->
                        <div class="swiper-slide">
                            <div class="journey-card bottom">

                                <span class="road-dot"></span>

                                <div class="year">2023</div>

                                <div class="icon">
                                    <i class="fas fa-users"></i>
                                </div>

                                <h4>Business Expansion</h4>

                                <p>
                                    Added two component supply customers and established
                                    a separate office of 100 sq.ft.
                                </p>

                                <div class="revenue">
                                    Revenue : ₹37 Lakhs
                                </div>

                            </div>
                        </div>

                        <!-- 2024 -->
                        <div class="swiper-slide">
                            <div class="journey-card top">

                                <span class="road-dot"></span>

                                <div class="year">2024</div>

                                <div class="icon">
                                    <i class="fas fa-industry"></i>
                                </div>

                                <h4>Wire Harness Manufacturing</h4>

                                <p>
                                    Received the first Wire Harness manufacturing order
                                    from TACO Tier-1 and expanded to a 200 sq.ft.
                                    manufacturing facility.
                                </p>

                                <div class="revenue">
                                    Revenue : ₹93 Lakhs
                                </div>

                            </div>
                        </div>

                        <!-- 2025 -->
                        <div class="swiper-slide">
                            <div class="journey-card bottom">

                                <span class="road-dot"></span>

                                <div class="year">2025</div>

                                <div class="icon">
                                    <i class="fas fa-cogs"></i>
                                </div>

                                <h4>Automotive Growth</h4>

                                <p>
                                    Added two automotive customers and expanded
                                    manufacturing space to 400 sq.ft.
                                </p>

                                <div class="revenue">
                                    Revenue : ₹98 Lakhs
                                </div>

                            </div>
                        </div>

                        <!-- 2026 -->
                        <div class="swiper-slide">
                            <div class="journey-card top">

                                <span class="road-dot"></span>

                                <div class="year">2026</div>

                                <div class="icon">
                                    <i class="fas fa-bolt"></i>
                                </div>

                                <h4>New Manufacturing Facility</h4>

                                <p>
                                    Established a 2,000 sq.ft. manufacturing facility
                                    for EV & Solar Control Panel Wire Harnesses.
                                </p>

                                <div class="revenue">
                                    Target : ₹1.4 Crore
                                </div>

                            </div>
                        </div>

                        <!-- 2027 -->
                        <div class="swiper-slide">
                            <div class="journey-card bottom">

                                <span class="road-dot"></span>

                                <div class="year">2027</div>

                                <div class="icon">
                                    <i class="fas fa-shield-alt"></i>
                                </div>

                                <h4>Military & Defence</h4>

                                <p>
                                    Started supplying Military & Defence Wire Harnesses
                                    with a projected revenue target of ₹3 Crore.
                                </p>

                                <div class="revenue">
                                    Target : ₹3 Crore
                                </div>

                            </div>
                        </div>

                    </div>

                    <!-- Navigation -->
                    <!--<div class="tp-project-prev">-->
                    <!--    <i class="far fa-arrow-left"></i>-->
                    <!--</div>-->

                    <!--<div class="tp-project-next">-->
                    <!--    <i class="far fa-arrow-right"></i>-->
                    <!--</div>-->

                </div>

            </div>
        </div>
    </div>

</section>
<section class="history-section d-none" style="background-image: url(&quot;assets/img/feature/bg-1.png&quot;);">
    <div class="container">
        <div class="section-title text-center mb-5">
            <span>CKT Journey</span>
            <h2>History & Milestones</h2>
            <p>Our journey of continuous growth, innovation, and manufacturing excellence.</p>
        </div>
<div class="timeline mt-70">

    <div class="timeline-item top">
        <div class="timeline-content">
            <div class="icon"><i class="fas fa-building"></i></div>
            <span class="year">2022</span>
            <h5>Company Registration</h5>
            <p>
                Company registered with GST, IEC & FF International account.
                Started operations from a shared office of 100 sq.ft.
            </p>
            <div class="revenue">Revenue : ₹14 Lakhs</div>
        </div>
    </div>

    <div class="timeline-item bottom">
        <div class="timeline-content">
            <div class="icon"><i class="fas fa-users"></i></div>
            <span class="year">2023</span>
            <h5>Business Expansion</h5>
            <p>
                Added two component supply customers and established a
                separate office of 100 sq.ft.
            </p>
            <div class="revenue">Revenue : ₹37 Lakhs</div>
        </div>
    </div>

    <div class="timeline-item top">
        <div class="timeline-content">
            <div class="icon"><i class="fas fa-industry"></i></div>
            <span class="year">2024</span>
            <h5>Wire Harness Manufacturing</h5>
            <p>
                Received the first wire harness manufacturing order from
                TACO Tier-1 and expanded to a 200 sq.ft. manufacturing facility.
            </p>
            <div class="revenue">Revenue : ₹93 Lakhs</div>
        </div>
    </div>

    <div class="timeline-item bottom">
        <div class="timeline-content">
            <div class="icon"><i class="fas fa-cogs"></i></div>
            <span class="year">2025</span>
            <h5>Automotive Growth</h5>
            <p>
                Added two automotive customers and expanded manufacturing
                space to 400 sq.ft.
            </p>
            <div class="revenue">Revenue : ₹98 Lakhs</div>
        </div>
    </div>

    <div class="timeline-item top">
        <div class="timeline-content">
            <div class="icon"><i class="fas fa-bolt"></i></div>
            <span class="year">2026</span>
            <h5>New Manufacturing Facility</h5>
            <p>
                Established a 2,000 sq.ft. manufacturing facility for EV &
                Solar Control Panel Wire Harnesses.
            </p>
            <div class="revenue">Target : ₹1.4 Crore</div>
        </div>
    </div>

    <div class="timeline-item bottom">
        <div class="timeline-content">
            <div class="icon"><i class="fas fa-shield-alt"></i></div>
            <span class="year">2027</span>
            <h5>Military & Defence</h5>
            <p>
                Started supplying Military & Defence Wire Harnesses with a
                projected revenue target of ₹3 Crore.
            </p>
            <div class="revenue">Target : ₹3 Crore</div>
        </div>
    </div>

</div>
    </div>
</section>
   
        <!-- choose area start -->
      <div class="tp-choose-2-area p-relative fix pt-70 pb-70">
         <div class="tp-choose-2-shape-1 d-none d-lg-block">
            <img src="assets/img/choose/shape-2-1.png" alt="">
         </div>
         <div class="tp-choose-2-shape-2 d-none d-xxl-block">
            <img src="assets/img/choose/shape-2-2.png" alt="">
         </div>
         <div class="tp-choose-2-bg" data-background="assets/Images/why-choose-1.jpg"></div>
         <div class="container">
            <div class="row">
               <div class="col-xl-8 col-lg-8">
                  <div class="tp-choose-2-item z-index-3">
                     <div class="tp-choose-2-section-box mb-25">
                        <span class="tp-section-subtitle">WHY CHOOSE CKT</span>
                        <h4 class="tp-section-title">Your Trusted Partner for <br> End-to-End Manufacturing Solutions</h4>
                     </div>
                     <div class="tp-choose-2-text mb-45">
                       <p>
        CKT combines engineering expertise, advanced manufacturing capabilities,
        quality assurance, and efficient supply chain management to deliver
        innovative, reliable, and customer-focused solutions for every industry.
    </p>
                     </div>
                    <div class="tp-choose-2-icon-wrap">

    <!-- Stability -->
    <div class="tp-choose-2-icon-box mb-30 d-flex align-items-start">
        <div class="tp-choose-2-icon">
            <span><i class="fas fa-shield-alt"></i></span>

        </div>
        <div class="tp-choose-2-icon-text">
            <h5>Stability</h5>
            <p>Building long-term partnerships through consistent performance, dependable service, and sustainable business practices.</p>
        </div>
    </div>

    <!-- Market Intelligence -->
    <div class="tp-choose-2-icon-box mb-30 d-flex align-items-start">
        <div class="tp-choose-2-icon">
           <span><i class="fas fa-chart-line"></i></span>
        </div>
        <div class="tp-choose-2-icon-text">
            <h5>Market Intelligence</h5>
            <p>Leveraging industry expertise and market insights to deliver innovative, competitive, and customer-focused solutions.</p>
        </div>
    </div>

    <!-- Sourcing & Procurement -->
    <div class="tp-choose-2-icon-box mb-30 d-flex align-items-start">
        <div class="tp-choose-2-icon">
           <span><i class="fas fa-boxes"></i></span>
        </div>
        <div class="tp-choose-2-icon-text">
            <h5>Sourcing &amp; Procurement</h5>
            <p>Ensuring high-quality materials, cost optimization, and reliable supplier partnerships for uninterrupted production.</p>
        </div>
    </div>

    <!-- Quality & Operations -->
    <div class="tp-choose-2-icon-box mb-30 d-flex align-items-start">
        <div class="tp-choose-2-icon">
           <span><i class="fas fa-cogs"></i></span>
        </div>
        <div class="tp-choose-2-icon-text">
            <h5>Quality &amp; Operations</h5>
            <p>Maintaining rigorous quality standards and operational excellence to deliver precision and reliability in every project.</p>
        </div>
    </div>

    <!-- Supply Chain Services -->
    <div class="tp-choose-2-icon-box d-flex align-items-start">
        <div class="tp-choose-2-icon">
        <span><i class="fas fa-truck"></i></span>
        </div>
        <div class="tp-choose-2-icon-text">
            <h5>Supply Chain Services</h5>
            <p>Providing seamless end-to-end supply chain management for efficient logistics, on-time delivery, and customer satisfaction.</p>
        </div>
    </div>

</div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- choose area end -->
        <!-- tp-brands-area-start -->
      <div class="tp-brands-area pt-80 pb-80">
         <div class="container-fluid container-1580">
                  <div class="row">
            <div class="col-12 text-center mb-50">
                <span class="tp-section-subtitle">Trusted By</span>
                <h2 class="tp-section-title">Our Clients</h2>
                <p>Proudly serving leading companies across diverse industries with reliable wire harness and interconnect solutions.</p>
            </div>
        </div>

            <div class="row">
               <div class="col-12">
                  <div class="swiper-container tp-brand-6-slide-active">
                     <div class="swiper-wrapper slide-transtion">
             <!-- Original -->
<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/drdo-logo.png" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/ecozen-logo-updated.png" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/SparkMindaGreenMobilitylogo.png" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/logo-tata-autocomp-blue.svg" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/logo-DNEmAKYs.webp" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/vacco-logo.png" alt=""></a>
    </div>
</div>
<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/client-logo-ckt.jpg" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/ecozen-logo-updated.png" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/SparkMindaGreenMobilitylogo.png" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/logo-tata-autocomp.svg" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/logo-DNEmAKYs.webp" alt=""></a>
    </div>
</div>

<div class="swiper-slide">
    <div class="tp-brand-6-item">
        <a href="#"><img src="assets/Images/brand/vacco-logo.png" alt=""></a>
    </div>
</div>


                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- tp-brands-area-end -->
  <!-- step area start -->
   <div class="tp-step-area pt-40 pb-60">
    <div class="container">
        <div class="row">

            <div class="col-xl-12">
                <div class="tp-step-section-box text-center mb-50">
                    <span class="tp-section-subtitle"><span>//</span>WHAT WE DO</span>
                    <h4 class="tp-section-title">
                        Complete Wire Harness <br>
                        & Engineering Solutions
                    </h4>
                    <p class="mt-3">
                     Chaitra Konnex Technology (CKT) delivers complete wire harness solutions—from component sourcing and prototype development to precision manufacturing, industrial automation, and electro-mechanical assembly—ensuring quality, reliability, and on-time delivery.
                    </p>
                </div>
            </div>

            <!-- Step 01 -->
            <div class="col-xl-3 col-lg-6 col-md-6 mb-60 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                <div class="tp-step-item-box">
                    <div class="tp-step-item p-relative text-center">
                        <div class="tp-step-icon">
                             <span><i class="flaticon-plug"></i></span>
                        </div>

                        <div class="tp-step-text">
                            <h5 class="tp-step-title">
                                <a href="#">Sourcing & Supply</a>
                            </h5>
                            <p>
                                Procurement and supply of quality electrical,
                                electronic and wire harness components through
                                trusted distribution partners.
                            </p>
                        </div>

                        <div class="tp-step-number">
                            <span>Step 01</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 02 -->
            <div class="col-xl-3 col-lg-6 col-md-6 mb-60 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".5s">
                <div class="tp-step-item-box ">
                    <div class="tp-step-item p-relative text-center">
                        <div class="tp-step-icon">
                                <span><i class="flaticon-problem-solving"></i></span>
                        </div>

                        <div class="tp-step-text">
                            <h5 class="tp-step-title">
                                <a href="#">Prototype Development</a>
                            </h5>
                            <p>
                                Engineering support, prototype development,
                                product validation and design assistance for
                                faster product realization.
                            </p>
                        </div>

                        <div class="tp-step-number">
                            <span>Step 02</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 03 -->
            <div class="col-xl-3 col-lg-6 col-md-6 mb-60 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".7s">
                <div class="tp-step-item-box">
                    <div class="tp-step-item p-relative text-center">
                        <div class="tp-step-icon">
                            <span><i class="flaticon-service"></i></span>
                        </div>

                        <div class="tp-step-text">
                            <h5 class="tp-step-title">
                                <a href="#">Wire Harness Manufacturing</a>
                            </h5>
                            <p>
                                Precision manufacturing of automotive,
                                defence, electronic PCB and panel wiring
                                harnesses with stringent quality standards.
                            </p>
                        </div>

                        <div class="tp-step-number">
                            <span>Step 03</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 04 -->
            <!--tp-step-item-box-pl-->
            <div class="col-xl-3 col-lg-6 col-md-6 mb-60 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".9s">
                <div class="tp-step-item-box ">
                    <div class="tp-step-item p-relative text-center">
                        <div class="tp-step-icon">
                             <span><i class="flaticon-creative"></i></span>
                        </div>

                        <div class="tp-step-text">
                            <h5 class="tp-step-title">
                                <a href="#">Automation & Assembly</a>
                            </h5>
                            <p>
                                Industrial automation, jigs & fixtures,
                                electro-mechanical assembly and complete
                                manufacturing support solutions.
                            </p>
                        </div>

                        <div class="tp-step-number">
                            <span>Step 04</span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
      <!-- step area end -->
  
<!-- choose area start -->
      <div class="tp-choose-3-area p-relative black-bg-2 pt-70 pb-70">
         <div class="tp-choose-3-bg" data-background="assets/Images/promise-1.png">
            <!--<div class="tp-choose-3-text d-none d-lg-block">-->
            <!--   <span>For emmergency</span>-->
            <!--   <a href="tel:+99934564234297">+999 345 6423 4297</a>-->
            <!--</div>-->
         </div>
         <div class="container">
            <div class="row">
               <div class="col-xl-6 col-lg-6 offset-lg-6 offset-xl-6  wow tpfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
               <div class="tp-choose-content tp-choose-item-wrap z-index">

    <div class="tp-choose-section-box mb-30">
        <span class="tp-section-subtitle text-color">
            <span>//</span>OUR PROMISE
        </span>

        <h4 class="tp-section-title text-white">
            Your Trusted Partner for <br>
            Wire Harness Solutions
        </h4>
    </div>

    <div class="tp-choose-text mb-50">
        <p>
            
            Chaitra Konnex Technology (CKT) goes beyond sourcing and procurement. We deliver complete wire harness manufacturing solutions backed by engineering expertise, optimized supply
            chain management, stringent quality standards, and reliable global support.
        </p>
    </div>

    <div class="tp-choose-wrap">
        <div class="row">

            <!-- Card 1 -->
            <div class="col-xl-6 col-lg-6 col-md-6 mb-20">
                <div class="tp-choose-item d-flex align-items-center">
                    <span><i class="flaticon-service"></i></span>
                    <h5 class="tp-choose-item-title">
                        End-to-End Wire Harness Solutions
                    </h5>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="col-xl-6 col-lg-6 col-md-6 mb-20">
                <div class="tp-choose-item d-flex align-items-center">
                    <span><i class="flaticon-price-tag"></i></span>
                    <h5 class="tp-choose-item-title">
                        Flexible Orders & Cost Optimization
                    </h5>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="col-xl-6 col-lg-6 col-md-6 mb-20">
                <div class="tp-choose-item d-flex align-items-center">
                    <span><i class="flaticon-electrician-1"></i></span>
                    <h5 class="tp-choose-item-title">
                        Optimized Supply Chain & On-Time Delivery
                    </h5>
                </div>
            </div>

            <!-- Card 4 -->
            <div class="col-xl-6 col-lg-6 col-md-6 mb-20">
                <div class="tp-choose-item d-flex align-items-center">
                    <span><i class="flaticon-battery"></i></span>
                    <h5 class="tp-choose-item-title">
                        Quality Control & Complete Documentation
                    </h5>
                </div>
            </div>

            <!-- Card 5 -->
            <div class="col-xl-6 col-lg-6 col-md-6 mb-20">
                <div class="tp-choose-item d-flex align-items-center">
                   <span>
    <i class="fas fa-diagram-project"></i>
</span>
                    <h5 class="tp-choose-item-title">
                        Dedicated Project & Technical Support
                    </h5>
                </div>
            </div>

            <!-- Card 6 -->
            <div class="col-xl-6 col-lg-6 col-md-6 mb-20">
                <div class="tp-choose-item d-flex align-items-center">
               <span>
    <i class="fas fa-earth-asia"></i>
</span>
                    <h5 class="tp-choose-item-title">
                        Global Presence with Local Customer Support
                    </h5>
                </div>
            </div>

        </div>
    </div>

</div>
               </div>
            </div>
         </div>
      </div>
      <!-- choose area end -->
      <!-- service area start -->
      <div class="tp-service-area tp-service-bg p-relative pt-70 pb-70"
         data-background="assets/img/service/bg-1-1.png">
         <div class="tp-service-shape-2 d-none d-xxl-block">
            <img src="assets/img/service/shape-1-3.png" alt="">
         </div>
         <div class="container">
            <div class="tp-service-wrap mb-50">
               <div class="row align-items-end">
                  <div class="col-xl-8 col-lg-8 col-md-9">
                     <div class="tp-service-section-box">
                        <span class="tp-section-subtitle"><i class="flaticon-flash"></i>Comprehensive Wire Harness Solutions for Every Industry</span>
                        <h4 class="tp-section-title">High-quality wire harness manufacturing for automotive, industrial, solar, and consumer electronics.</h4>
                     </div>
                  </div>
                  <div class="col-xl-4 col-lg-4 col-md-3">
                     <div class="tp-service-slider-arrow d-flex justify-content-start  justify-content-md-end">
                        <button class="test-next"><i class="far fa-arrow-left"></i></button>
                        <button class="test-prev active"><i class="far fa-arrow-right"></i></button>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-xl-12">
                  <div class="tp-service-wrapper">
                     <div class="swiper-container tp-service-active">
                        <div class="swiper-wrapper">
                           <div class="swiper-slide">
                              <div class="tp-service-item p-relative">
                                 <div class="tp-service-thumb">
                                   <img src="assets/Images/ev-charging.jpg" alt="">
                                 </div>
                                 <div class="tp-service-content-box">
                                    <div class="tp-service-content fix">
                                       <div class="tp-service-icon p-relative">
                                          <span><i class="flaticon-lamp"></i></span>
                                          <div class="tp-service-icon-shape">
                                             <img src="assets/img/service/shape-1-1.png" alt="">
                                          </div>
                                       </div>
                                       <div class="tp-service-text pb-5">
                                          <h4 class="tp-service-title">
                                             <a href="service-details2.php">EV Charging Solutions</a>
                                          </h4>
                                          <p>Battery cables, charger gun harnesses, inlet socket harnesses, and high-voltage EV wiring.</p>
                                       </div>
                                       <div class="tp-service-arrow">
                                          <a href="service-details2.php">Read More<i
                                                class="flaticon-right-arrow"></i></a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-service-shape-1">
                                    <img src="assets/img/service/shape-1-2.png" alt="">
                                 </div>
                              </div>
                           </div>
                           <div class="swiper-slide">
                              <div class="tp-service-item p-relative">
                                 <div class="tp-service-thumb">
                                    <img src="assets/Images/automatic-wire-harness.jpg" alt="">
                                 </div>
                                 <div class="tp-service-content-box">
                                    <div class="tp-service-content fix">
                                       <div class="tp-service-icon p-relative">
                                          <span><i class="flaticon-air-conditioner"></i></span>
                                          <div class="tp-service-icon-shape">
                                             <img src="assets/img/service/shape-1-1.png" alt="">
                                          </div>
                                       </div>
                                       <div class="tp-service-text pb-5">
                                          <h4 class="tp-service-title">
                                             <a href="service-details1.php">Automotive Wire Harness</a>
                                          </h4>
                                          <p>Reliable wiring systems for EVs, IC engine vehicles, and commercial automotive applications.</p>
                                       </div>
                                       <div class="tp-service-arrow">
                                          <a href="service-details1.php">Read More<i
                                                class="flaticon-right-arrow"></i></a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-service-shape-1">
                                    <img src="assets/img/service/shape-1-2.png" alt="">
                                 </div>
                              </div>
                           </div>
                           <div class="swiper-slide">
                              <div class="tp-service-item p-relative">
                                 <div class="tp-service-thumb">
                                    <img src="assets/Images/product/defence-img.jpeg" alt="">
                                 </div>
                                 <div class="tp-service-content-box">
                                    <div class="tp-service-content fix">
                                       <div class="tp-service-icon p-relative">
                                          <span><i class="flaticon-heater"></i></span>
                                          <div class="tp-service-icon-shape">
                                             <img src="assets/img/service/shape-1-1.png" alt="">
                                          </div>
                                       </div>
                                       <div class="tp-service-text pb-5">
                                          <h4 class="tp-service-title">
                                             <a href="service-details3.php">Home Appliance Harness</a>
                                          </h4>
                                          <p>Precision wire harnesses for refrigerators, washing machines, air conditioners, and other appliances.</p>
                                       </div>
                                       <div class="tp-service-arrow">
                                          <a href="service-details3.php">Read More<i
                                                class="flaticon-right-arrow"></i></a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-service-shape-1">
                                    <img src="assets/img/service/shape-1-2.png" alt="">
                                 </div>
                              </div>
                           </div>
                              <div class="swiper-slide">
                              <div class="tp-service-item p-relative">
                                 <div class="tp-service-thumb">
                                       <img src="assets/Images/LightingIndustrialHarness.jpg" alt="">
                                 </div>
                                 <div class="tp-service-content-box">
                                    <div class="tp-service-content fix">
                                       <div class="tp-service-icon p-relative">
                                          <span><i class="flaticon-heater"></i></span>
                                          <div class="tp-service-icon-shape">
                                             <img src="assets/img/service/shape-1-1.png" alt="">
                                          </div>
                                       </div>
                                       <div class="tp-service-text pb-5">
                                          <h4 class="tp-service-title">
                                             <a href="service-details5.php">Lighting & Industrial Harness</a>
                                          </h4>
                                          <p>Durable wiring solutions for LED lighting, switches, sensors, HVAC systems, and industrial equipment.</p>
                                       </div>
                                       <div class="tp-service-arrow">
                                          <a href="service-details5.php">Read More<i
                                                class="flaticon-right-arrow"></i></a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-service-shape-1">
                                    <img src="assets/img/service/shape-1-2.png" alt="">
                                 </div>
                              </div>
                           </div>
                              <div class="swiper-slide">
                              <div class="tp-service-item p-relative">
                                 <div class="tp-service-thumb">
                                    <img src="assets/Images/solare-panel-wire.jpg" alt="">
                                 </div>
                                 <div class="tp-service-content-box">
                                    <div class="tp-service-content fix">
                                       <div class="tp-service-icon p-relative">
                                          <span><i class="flaticon-heater"></i></span>
                                          <div class="tp-service-icon-shape">
                                             <img src="assets/img/service/shape-1-1.png" alt="">
                                          </div>
                                       </div>
                                       <div class="tp-service-text pb-5">
                                          <h4 class="tp-service-title">
                                             <a href="service-details4.php">Solar & Control Panel Wiring</a>
                                          </h4>
                                          <p>Customized cable assemblies for solar energy systems, control panels, and industrial automation.</p>
                                       </div>
                                       <div class="tp-service-arrow">
                                          <a href="service-details4.php">Read More<i
                                                class="flaticon-right-arrow"></i></a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-service-shape-1">
                                    <img src="assets/img/service/shape-1-2.png" alt="">
                                 </div>
                              </div>
                           </div>
                             <div class="swiper-slide">
                              <div class="tp-service-item p-relative">
                                 <div class="tp-service-thumb">
                                    <img src="assets/Images/custom-wire-harnesss.jpg" alt="">
                                 </div>
                                 <div class="tp-service-content-box">
                                    <div class="tp-service-content fix">
                                       <div class="tp-service-icon p-relative">
                                          <span><i class="flaticon-lighting"></i></span>
                                          <div class="tp-service-icon-shape">
                                             <img src="assets/img/service/shape-1-1.png" alt="">
                                          </div>
                                       </div>
                                       <div class="tp-service-text pb-5">
                                          <h4 class="tp-service-title">
                                             <a href="service-details6.php">Custom Design & Production</a>
                                          </h4>
                                          <p>End-to-end support from prototype development to mass production with strict quality assurance.</p>
                                       </div>
                                       <div class="tp-service-arrow">
                                          <a href="service-details6.php">Read More<i
                                                class="flaticon-right-arrow"></i></a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-service-shape-1">
                                    <img src="assets/img/service/shape-1-2.png" alt="">
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- service area end -->


      <!-- funfact area  start -->
      <div class="tp-funfact-area fix p-relative grey-bg pt-60 pb-65">
         <div class="tp-funfact-shape-1">
            <img src="assets/img/funfact/shape-1-1.png" alt="">
         </div>
         <div class="tp-funfact-shape-2 d-none d-xl-block">
            <img src="assets/img/funfact/shape-1-2.png" alt="">
         </div>
         <div class="container">
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 mb-30">
                  <div class="tp-funfact-item text-center">
                     <div class="tp-funfact-icon">
                        <span><i class="flaticon-solution"></i></span>
                     </div>
                     <div class="tp-funfact-content">
                        <h5 class="tp-funfact-number"><i class="purecounter" data-purecounter-duration="1"
                              data-purecounter-end="80">0</i>+</h5>
                        <span>Succesfull Projects</span>
                     </div>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 mb-30">
                  <div class="tp-funfact-item text-center">
                     <div class="tp-funfact-icon">
                        <span><i class="flaticon-customer-service"></i></span>
                     </div>
                     <div class="tp-funfact-content">
                        <h5 class="tp-funfact-number"><i class="purecounter" data-purecounter-duration="1"
                              data-purecounter-end="9">0</i>+</h5>
                        <span>Satisfied Clients</span>
                     </div>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 mb-30">
                  <div class="tp-funfact-item text-center">
                     <div class="tp-funfact-icon">
                        <span><i class="flaticon-customer-service-1"></i></span>
                     </div>
                     <div class="tp-funfact-content">
                        <h5 class="tp-funfact-number"><i class="purecounter" data-purecounter-duration="1"
                              data-purecounter-end="10">0</i>+</h5>
                        <span>Experienced Staff</span>
                     </div>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 mb-30">
                  <div class="tp-funfact-item text-center">
                     <div class="tp-funfact-icon">
                        <span><i class="flaticon-trophy"></i></span>
                     </div>
                     <div class="tp-funfact-content">
                        <h5 class="tp-funfact-number"><i class="purecounter" data-purecounter-duration="1"
                              data-purecounter-end="8"></i>+</h5>
                        <span>Awards Winning</span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- funfact area end -->


   </main>
<?php include 'footer.php'; ?>